# IP 地址计算器（Android）

输入一个 IPv4 地址或 IPv4 网段，直接算出网段关键信息；也可以把一个网段继续切分为更小的子网。

## 功能
- 支持三种输入写法：
  - `192.168.1.10/24`（CIDR）
  - `192.168.1.10 255.255.255.0`（地址 + 子网掩码）
  - `192.168.1.10`（只给地址，按 A/B/C 类给默认掩码）
- 输出：IP 地址、CIDR、子网掩码、通配符（反掩码）、网络地址、广播地址、可用地址范围、可用主机数、地址类型（私有/公网/回环/组播等）、地址类别、主机位、二进制（网络位与主机位分界）
- 任意一行点击即复制该值
- 子网切分：把当前网段按新的前缀长度切开，列出子网段与地址范围（最多展示前 32 个）

## 构建
不使用 Gradle，手工命令行构建：

```
cd ipcalc && ./build.sh
```

链路：`aapt2 compile/link → javac → d8 → zipalign → apksigner`。
JDK 17、Android SDK build-tools 34.0.0、platform android-34。

签名使用独立 release 密钥库（`../secrets/ipcalc-release.keystore`，别名 `ipcalcrelease`），密钥库不随源码公开。

## 规格
- 包名：`com.example.ipcalculator`
- minSdk 24 / targetSdk 34
- 当前版本：v1.0.1（versionCode 2）
- 无任何网络权限，全部本地计算
