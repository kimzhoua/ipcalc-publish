package com.example.ipcalculator;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * IP 地址计算器：输入 IPv4 地址或 CIDR，输出网段各项关键信息，并支持子网切分。
 */
public class MainActivity extends Activity {

    private OtaManager otaManager;
    private EditText input;
    private LinearLayout resultCard;
    private LinearLayout splitList;
    private EditText splitPrefix;
    private TextView errorText;

    private long lastNetwork = -1L;
    private int lastPrefix = 24;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        otaManager = new OtaManager(this);
        buildUi();
    }

    // ================= UI =================

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(0xFFF6F7FB);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(26), dp(18), dp(30));

        TextView title = new TextView(this);
        title.setText("IP 地址计算器");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFF1B2230);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("换算网络地址、掩码、可用主机范围，也可切分子网");
        sub.setTextSize(13);
        sub.setTextColor(0xFF6B7482);
        sub.setPadding(0, dp(6), 0, dp(16));
        root.addView(sub);

        // ---- 输入卡 ----
        LinearLayout inputCard = card();
        TextView label = new TextView(this);
        label.setText("IP 地址 / 网段");
        label.setTextSize(13);
        label.setTextColor(0xFF6B7482);
        inputCard.addView(label);

        input = new EditText(this);
        input.setText("192.168.1.10/24");
        input.setTextSize(17);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        input.setTextColor(0xFF1B2230);
        input.setHint("例如 192.168.1.10/24 或 192.168.1.10 255.255.255.0");
        input.setPadding(dp(14), dp(12), dp(14), dp(12));
        input.setBackground(rounded(0xFFF6F7FB, 12));
        LinearLayout.LayoutParams inLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        inLp.topMargin = dp(8);
        input.setLayoutParams(inLp);
        inputCard.addView(input);

        TextView calcBtn = new TextView(this);
        calcBtn.setText("计算");
        calcBtn.setTextSize(16);
        calcBtn.setTypeface(Typeface.DEFAULT_BOLD);
        calcBtn.setTextColor(0xFFFFFFFF);
        calcBtn.setGravity(Gravity.CENTER);
        calcBtn.setBackground(rounded(0xFF2F6BFF, 14));
        LinearLayout.LayoutParams cbLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        cbLp.topMargin = dp(12);
        calcBtn.setLayoutParams(cbLp);
        calcBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculate();
            }
        });
        inputCard.addView(calcBtn);

        errorText = new TextView(this);
        errorText.setTextSize(12);
        errorText.setTextColor(0xFFE0455E);
        errorText.setPadding(dp(2), dp(8), dp(2), 0);
        errorText.setVisibility(View.GONE);
        inputCard.addView(errorText);

        root.addView(inputCard);

        // ---- 结果卡 ----
        resultCard = card();
        root.addView(resultCard);

        // ---- 子网切分卡 ----
        LinearLayout splitCard = card();
        TextView splitTitle = new TextView(this);
        splitTitle.setText("子网切分");
        splitTitle.setTextSize(15);
        splitTitle.setTypeface(Typeface.DEFAULT_BOLD);
        splitTitle.setTextColor(0xFF1B2230);
        splitCard.addView(splitTitle);

        TextView splitHint = new TextView(this);
        splitHint.setText("把这个网段按新的前缀长度切开，例如 /24 切成 /26");
        splitHint.setTextSize(12);
        splitHint.setTextColor(0xFF6B7482);
        splitHint.setPadding(0, dp(4), 0, dp(10));
        splitCard.addView(splitHint);

        LinearLayout splitRow = new LinearLayout(this);
        splitRow.setOrientation(LinearLayout.HORIZONTAL);
        splitRow.setGravity(Gravity.CENTER_VERTICAL);

        splitPrefix = new EditText(this);
        splitPrefix.setHint("新前缀，如 26");
        splitPrefix.setTextSize(15);
        splitPrefix.setSingleLine(true);
        splitPrefix.setInputType(InputType.TYPE_CLASS_NUMBER);
        splitPrefix.setPadding(dp(14), dp(10), dp(14), dp(10));
        splitPrefix.setBackground(rounded(0xFFF6F7FB, 12));
        splitPrefix.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        splitRow.addView(splitPrefix);

        TextView splitBtn = new TextView(this);
        splitBtn.setText("切分");
        splitBtn.setTextSize(15);
        splitBtn.setTextColor(0xFF2F6BFF);
        splitBtn.setGravity(Gravity.CENTER);
        GradientDrawable splitBg = rounded(0xFFF1F5FF, 12);
        splitBtn.setBackground(splitBg);
        LinearLayout.LayoutParams sbLp = new LinearLayout.LayoutParams(dp(84), dp(44));
        sbLp.leftMargin = dp(10);
        splitBtn.setLayoutParams(sbLp);
        splitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                splitSubnets();
            }
        });
        splitRow.addView(splitBtn);
        splitCard.addView(splitRow);

        splitList = new LinearLayout(this);
        splitList.setOrientation(LinearLayout.VERTICAL);
        splitList.setPadding(0, dp(10), 0, 0);
        splitCard.addView(splitList);

        root.addView(splitCard);

        // ---- 版本与更新 ----
        LinearLayout upd = new LinearLayout(this);
        upd.setOrientation(LinearLayout.HORIZONTAL);
        upd.setGravity(Gravity.CENTER_VERTICAL);
        upd.setPadding(dp(4), dp(18), dp(4), 0);

        TextView ver = new TextView(this);
        ver.setText("IP地址计算器 v" + versionName());
        ver.setTextSize(12);
        ver.setTextColor(0xFF98A0AE);
        ver.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        upd.addView(ver);

        TextView check = new TextView(this);
        check.setText("检查更新");
        check.setTextSize(12);
        check.setTextColor(0xFF2F6BFF);
        check.setPadding(dp(8), dp(4), dp(2), dp(4));
        check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                otaManager.checkUpdate(true);
            }
        });
        upd.addView(check);
        root.addView(upd);

        // 首次自动计算
        calculate();

        scroll.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackground(rounded(0xFFFFFFFF, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(12);
        c.setLayoutParams(lp);
        return c;
    }

    // ================= 计算 =================

    private void calculate() {
        String raw = input.getText().toString().trim();
        if (raw.length() == 0) {
            showError("请输入 IP 地址");
            return;
        }
        long ip;
        int prefix;
        try {
            Object[] parsed = parseInput(raw);
            ip = (Long) parsed[0];
            prefix = (Integer) parsed[1];
        } catch (Exception e) {
            showError(e.getMessage() == null ? "格式不正确" : e.getMessage());
            return;
        }
        hideError();

        long mask = prefix == 0 ? 0L : (0xFFFFFFFFL << (32 - prefix)) & 0xFFFFFFFFL;
        long network = ip & mask;
        long broadcast = network | (~mask & 0xFFFFFFFFL);
        int hostBits = 32 - prefix;
        long hostCount;
        long firstHost;
        long lastHost;
        if (hostBits == 0) {
            hostCount = 1;
            firstHost = network;
            lastHost = network;
        } else if (hostBits == 1) {
            hostCount = 2;
            firstHost = network;
            lastHost = broadcast;
        } else {
            hostCount = (1L << hostBits) - 2;
            firstHost = network + 1;
            lastHost = broadcast - 1;
        }

        lastNetwork = network;
        lastPrefix = prefix;

        resultCard.removeAllViews();

        TextView head = new TextView(this);
        head.setText("计算结果");
        head.setTextSize(15);
        head.setTypeface(Typeface.DEFAULT_BOLD);
        head.setTextColor(0xFF1B2230);
        head.setPadding(0, 0, 0, dp(6));
        resultCard.addView(head);

        addRow(resultCard, "IP 地址", ipToString(ip), true);
        addRow(resultCard, "CIDR 表示", ipToString(ip) + "/" + prefix, false);
        addRow(resultCard, "子网掩码", ipToString(mask), true);
        addRow(resultCard, "通配符（反掩码）", ipToString(~mask & 0xFFFFFFFFL), false);
        addRow(resultCard, "网络地址", ipToString(network), true);
        addRow(resultCard, "广播地址", ipToString(broadcast), true);
        addRow(resultCard, "可用地址范围",
                hostBits <= 1 ? ipToString(firstHost) + " – " + ipToString(lastHost)
                        : ipToString(firstHost) + " – " + ipToString(lastHost), false);
        addRow(resultCard, "可用主机数", String.valueOf(hostCount), false);
        addRow(resultCard, "地址类型", addressType(ip), false);
        addRow(resultCard, "地址类别", ipClass(ip), false);
        addRow(resultCard, "主机位", hostBits + " 位（可用 " + hostCount + " 台）", false);
        addRow(resultCard, "二进制（网络部分）", binaryString(network, prefix), false);

        TextView tip = new TextView(this);
        tip.setText("点任意一行可复制该值");
        tip.setTextSize(11);
        tip.setTextColor(0xFF98A0AE);
        tip.setPadding(dp(2), dp(12), 0, 0);
        resultCard.addView(tip);
    }

    private void splitSubnets() {
        if (lastNetwork < 0) {
            Toast.makeText(this, "请先计算一个网段", Toast.LENGTH_SHORT).show();
            return;
        }
        int newPrefix;
        try {
            newPrefix = Integer.parseInt(splitPrefix.getText().toString().trim());
        } catch (Exception e) {
            Toast.makeText(this, "请输入新的前缀长度，例如 26", Toast.LENGTH_SHORT).show();
            return;
        }
        if (newPrefix <= lastPrefix || newPrefix > 32) {
            Toast.makeText(this, "新前缀要大于 " + lastPrefix + " 且不超过 32",
                    Toast.LENGTH_SHORT).show();
            return;
        }
        int bits = newPrefix - lastPrefix;
        long count = 1L << bits;
        long step = 1L << (32 - newPrefix);

        splitList.removeAllViews();
        int show = (int) Math.min(count, 32);

        TextView sum = new TextView(this);
        sum.setText("共 " + count + " 个子网，每个 " + (long) Math.pow(2, 32 - newPrefix)
                + " 个地址" + (count > show ? "（仅列出前 " + show + " 个）" : ""));
        sum.setTextSize(12);
        sum.setTextColor(0xFF6B7482);
        sum.setPadding(0, 0, 0, dp(8));
        splitList.addView(sum);

        for (int i = 0; i < show; i++) {
            long net = lastNetwork + i * step;
            final String text = ipToString(net) + "/" + newPrefix
                    + "    " + ipToString(net) + " – " + ipToString(net + step - 1);
            TextView row = new TextView(this);
            row.setText((i + 1) + ".  " + text);
            row.setTextSize(13);
            row.setTextColor(0xFF1B2230);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(rounded(0xFFF6F7FB, 10));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = dp(6);
            row.setLayoutParams(rlp);
            row.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    copy(text.replace("    ", " "));
                }
            });
            splitList.addView(row);
        }
    }

    // ================= 结果行 =================

    private void addRow(LinearLayout parent, String name, final String value, boolean bold) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(10), 0, dp(10));

        TextView n = new TextView(this);
        n.setText(name);
        n.setTextSize(13);
        n.setTextColor(0xFF6B7482);
        n.setLayoutParams(new LinearLayout.LayoutParams(dp(112),
                ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(n);

        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(14);
        v.setTextColor(0xFF1B2230);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(v);

        View line = new View(this);
        line.setBackgroundColor(0xFFEDF0F5);
        line.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(1)));

        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v2) {
                copy(value);
            }
        });

        parent.addView(row);
        parent.addView(line);
    }

    private void copy(String text) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("IP 计算结果", text));
            Toast.makeText(this, "已复制：" + text, Toast.LENGTH_SHORT).show();
        }
    }

    private void showError(String msg) {
        errorText.setText(msg);
        errorText.setVisibility(View.VISIBLE);
        resultCard.removeAllViews();
    }

    private void hideError() {
        errorText.setVisibility(View.GONE);
    }

    // ================= 解析与格式化 =================

    private Object[] parseInput(String raw) {
        String s = raw.replace('／', '/').replace('，', ',').replace('　', ' ').trim();
        s = s.replaceAll("\\s+/", "/");

        long ip;
        int prefix = -1;

        if (s.contains("/")) {
            String[] parts = s.split("/");
            if (parts.length != 2) throw new IllegalArgumentException("格式应为 192.168.1.10/24");
            ip = parseIp(parts[0].trim());
            String p = parts[1].trim();
            if (p.contains(".")) {
                prefix = maskToPrefix(parseIp(p));
            } else {
                try {
                    prefix = Integer.parseInt(p);
                } catch (Exception e) {
                    throw new IllegalArgumentException("前缀长度应为 0–32 的数字");
                }
            }
        } else {
            String[] parts = s.split("\\s+");
            ip = parseIp(parts[0].trim());
            if (parts.length >= 2) {
                prefix = maskToPrefix(parseIp(parts[1].trim()));
            } else {
                // 未给掩码时按类别默认：A/8、B/16、C/24
                prefix = ip >> 24 < 128 ? 8 : (ip >> 24 < 192 ? 16 : 24);
            }
        }
        if (prefix < 0 || prefix > 32) {
            throw new IllegalArgumentException("前缀长度应在 0–32 之间");
        }
        return new Object[]{ip, prefix};
    }

    private long parseIp(String s) {
        String[] p = s.split("\\.");
        if (p.length != 4) throw new IllegalArgumentException("IP 应为四段，例如 192.168.1.10");
        long v = 0;
        for (String part : p) {
            int n;
            try {
                n = Integer.parseInt(part.trim());
            } catch (Exception e) {
                throw new IllegalArgumentException("每段应是 0–255 的数字");
            }
            if (n < 0 || n > 255) throw new IllegalArgumentException("每段应在 0–255 之间");
            v = (v << 8) | n;
        }
        return v;
    }

    private int maskToPrefix(long mask) {
        // 掩码必须连续：统计左侧 1 的个数，并校验低位全 0
        int prefix = 0;
        long m = mask;
        while ((m & 0x80000000L) != 0) {
            prefix++;
            m = (m << 1) & 0xFFFFFFFFL;
        }
        if (m != 0) throw new IllegalArgumentException("子网掩码不连续，例如应为 255.255.255.0");
        return prefix;
    }

    private String ipToString(long v) {
        return ((v >> 24) & 0xFF) + "." + ((v >> 16) & 0xFF) + "."
                + ((v >> 8) & 0xFF) + "." + (v & 0xFF);
    }

    private String binaryString(long v, int prefix) {
        StringBuilder bits = new StringBuilder();
        for (int i = 31; i >= 0; i--) bits.append(((v >> i) & 1) == 1 ? '1' : '0');
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < 32; i++) {
            if (i > 0 && i % 8 == 0) out.append(' ');
            if (i > 0 && i == prefix) out.append("| ");
            out.append(bits.charAt(i));
        }
        return out.toString();
    }

    private String ipClass(long ip) {
        long first = (ip >> 24) & 0xFF;
        if (first < 128) return "A 类（1–126）";
        if (first < 192) return "B 类（128–191）";
        if (first < 224) return "C 类（192–223）";
        if (first < 240) return "D 类（组播）";
        return "E 类（保留/实验）";
    }

    private String addressType(long ip) {
        long first = (ip >> 24) & 0xFF;
        long second = (ip >> 16) & 0xFF;
        if (first == 10) return "私有地址（10.0.0.0/8）";
        if (first == 172 && second >= 16 && second <= 31) return "私有地址（172.16.0.0/12）";
        if (first == 192 && second == 168) return "私有地址（192.168.0.0/16）";
        if (first == 127) return "回环地址（本机）";
        if (first == 169 && second == 254) return "链路本地（自动私有地址）";
        if (first >= 224 && first < 240) return "组播地址";
        if (first >= 240) return "保留地址";
        if (first == 0) return "本网络（保留）";
        if (first == 100 && second >= 64 && second <= 127) return "运营商级 NAT（100.64.0.0/10）";
        return "公网地址";
    }

    // ================= 工具 =================

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    @Override
    protected void onDestroy() {
        if (otaManager != null) otaManager.release();
        super.onDestroy();
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
